document.addEventListener('DOMContentLoaded', ()=>{
  const copyBtn = document.getElementById('copyEmail');
  const emailEl = document.getElementById('email');
  if(copyBtn && emailEl){
    copyBtn.addEventListener('click', async ()=>{
      try{
        await navigator.clipboard.writeText(emailEl.textContent.trim());
        copyBtn.textContent = '✔';
        setTimeout(()=> copyBtn.textContent = '📋', 1500);
      }catch(e){
        alert('No se pudo copiar el correo. Seleccione y copie manualmente.');
      }
    });
  }
  const downloadBtn = document.getElementById('downloadPdf');
  if(downloadBtn){
    downloadBtn.addEventListener('click', ()=>{
      window.print();
    });
  }
});